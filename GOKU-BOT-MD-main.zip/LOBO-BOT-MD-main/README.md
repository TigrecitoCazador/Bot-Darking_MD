🍁𝐇𝐎𝐋𝐀 𝐒𝐎𝐘 𝐄𝐍𝐃𝐄𝐑 𝐋𝐃 , 𝐋𝐈𝐃𝐄𝐑 𝐃𝐄 𝐋𝐀 𝐔𝐍𝐈𝐎𝐍 𝐈𝐍𝐓𝐄𝐑𝐍𝐀𝐂𝐈𝐎𝐍𝐀𝐋 𝐘 𝐂𝐎𝐋𝐀𝐁𝐎𝐑𝐀𝐃𝐎𝐑 𝐃𝐄 𝐁𝐎𝐓𝐒 𝐏𝐀𝐑𝐀 𝐖𝐇𝐀𝐒𝐏 


☃️𝐄𝐒𝐓𝐄 𝐄𝐒 𝐄𝐋 𝐑𝐄𝐏𝐎𝐒𝐈𝐓𝐎𝐑𝐈𝐎 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 𝐃𝐄 (𝗟𝗢𝗕𝗢-𝗕𝗢𝗧-𝗠𝗗)
𝗬 𝗧𝗘 𝗜𝗡𝗩𝗜𝗧𝗢 𝗔 𝗗𝗔𝗥𝗟𝗘 𝗨𝗡𝗔 𝗘𝗦𝗧𝗥𝗘𝗟𝗟𝗔 𝗔𝗟 𝗥𝗘𝗣𝗢 𝗦𝗜 𝗧𝗘 𝗚𝗨𝗦𝗧𝗔🌟

# `🐺 𝗟𝗢𝗕𝗢-𝗕𝗢𝗧-𝗠𝗗 🐺` 
<p align="center">
<img src="https://i.ibb.co/wYRhwjt/lobo-bot.jpg" alt="LoboBot-MD" width="900"/>
</p>
------------------



### `—◉ 🤖 BOTS OFICIALES 🤖`

<a href="https://api.whatsapp.com/send/?phone=593939005387&text=/estado&type=phone_number&app_absent=0" target="blank"><img src="https://img.shields.io/badge/BOT_OFICIAL_1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />



 > NO SPAMEAR COMANDOS


### `—◉ 🖍 LETRA DEL BOT 🖍`
- PAGINA USADA PARA LA LETRA [Aqui](https://smiley.cool/es/weirdmaker.php)


### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/BrunoSobrino/Hachiko-Bot-MD/fork)

  
### `—◉ 💥 ACTIVAR EN KOYEB 💥`

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=https://github.com/BrunoSobrino/TheMystic-Bot-MD&branch=master&name=mysticbot)
  
### `—◉ 🌌 ACTIVAR EN REPLIT 🌌`

[![Run on Repl.it](https://repl.it/badge/github/BrunoSobrino/TheMystic-Bot-MD)](https://repl.it/github/BrunoSobrino/TheMystic-Bot-MD) 
  
### `—◉ 🔰 ACTIVAR EN RENDER 🔰`

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FBrunoSobrino%2FTheMystic-Bot-MD) 

### `—◉ 👾 ACTIVAR EN TERMUX 👾` 
- ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
```bash
cd && termux-setup-storage
```

```bash
apt-get update -y && apt-get upgrade -y
```

```bash
pkg install -y git nodejs ffmpeg imagemagick && pkg install yarn 
```

```bash
git clone https://github.com/Ender-GB-Isis777/LOBO-BOT-MD.git && cd LOBO-BOT-MD
```

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE EN TERMUX ✔️`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd LOBO-termux
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR EN TERMUX 👽`
- DETENER EL BOT DANDO CLICK EN EL SIMBOLO CTROL EN TERMUX MAS LA LETRA Z EN SU TECLADO MOVIL HASTA QUE SALGA ALGO EN VERDE SIMILAR A Lobo-termux $  
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd LOBO-termux
> rm -rf LOBOsession
> npm start
```



 ### `—◉ 👑 DUDAS SOBRE EL BOT?,CONTACTA AL CREADOR 👑`
<a href="http://wa.me/50576390682" target="blank"><img src="https://img.shields.io/badge/ENDER_GB_CREADOR-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

### `—◉ ✦CUSTOMER SUPPORT✦`
<a href="http://wa.me/50576390682" target="blank"><img src="https://img.shields.io/badge/ENDER_GB_COSTOMER_SUPPORT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

## `COLABORADORES DEL BOT` 
<a href="[https://github.com/Ender-GB-Isis777]"><img src="https://github.com/Ender-GB-Isis777.png" width="100" height="100" alt="Ender"/></a>
<a href="[https://github.com/Jxtxn17]"><img src="https://github.com/Jxtxn17.png" width="100" height="100" alt="Jxtxn"/></a>


## `AGRADECIMIENTOS & CREDITOS` 
<div><button id="boton" type="button">games-wabot-md - By BochilGaming </button></div>
<a href="https://github.com/BochilGaming/games-wabot-md/tree/multi-device"><img src="https://github.com/BochilGaming.png" width="150" height="150" alt="BochilGaming"/></a>
<div><button id="boton" type="button">Baileys - By WhiskeySockets & adiwajshing</button></div>
<a href="https://github.com/WhiskeySockets/Baileys"><img src="https://github.com/WhiskeySockets.png" width="150" height="150" alt="adiwajshing"/></a>

## `EDITOR & PROPIETARIO DEL BOT` 
<a href="https://github.com/Ender-GB-Isis777"><img src="https://github.com/Ender-GB-Isis777.png" width="250" height="250" alt="Ender"/></a>
  
`Lobo-Bot-MD - By Ender GB`
