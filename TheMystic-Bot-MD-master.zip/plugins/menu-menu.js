import fetch from 'node-fetch';
const handler = async (m, {conn, usedPrefix, usedPrefix: _p, __dirname, text, isPrems}) => {
  if (usedPrefix == 'a' || usedPrefix == 'A') return;
  try {
    const pp = imagen4;
    // let vn = './media/menu.mp3'
    const img = './Menu2.jpg';
    const d = new Date(new Date + 3600000);
    const locale = 'es';
    const week = d.toLocaleDateString(locale, {weekday: 'long'});
    const date = d.toLocaleDateString(locale, {day: 'numeric', month: 'long', year: 'numeric'});
    const _uptime = process.uptime() * 1000;
    const uptime = clockString(_uptime);
    const user = global.db.data.users[m.sender];
    const {money, joincount} = global.db.data.users[m.sender];
    const {exp, limit, level, role} = global.db.data.users[m.sender];
    const rtotalreg = Object.values(global.db.data.users).filter((user) => user.registered == true).length;
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(850);
    const taguser = '@' + m.sender.split('@s.whatsapp.net')[0];
    const doc = ['pdf', 'zip', 'vnd.openxmlformats-officedocument.presentationml.presentation', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const document = doc[Math.floor(Math.random() * doc.length)];
    const str = `╭═══〘 ✯✯✯✯✯✯✯✯✯ 〙══╮
║    ◉— *DARKING-BOT* —◉
║≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡║
║➤ *𝗛ola, ${taguser}*
║≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡║
║➤ *Owner:* José Elber 
║➤ *Numero:* wa.me/972555538071
║➤ *Bot ofc:* wa.me/51975985721
║➤ *PayPal:* https://paypal.me/Jorgezamas2004?country.x=PE&locale.x=es_XC
║➤ *Fecha:* ${date}
║➤ *Tiempo activo:* ${uptime}
║➤ *Usuarios:* ${rtotalreg}
╰═══╡✯✯✯✯✯✯✯✯✯╞═══╯

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕀ℕ𝔽𝕆 𝔻𝔼𝕃 𝕌𝕊𝕌𝔸ℝ𝕀𝕆 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ *🎖️ Nivel:* ${level}
┣ *🧰 Experiencia:* ${exp}
┣ *⚓ Rango:* ${role}
┣ *💎 Diamantes:* ${limit}
┣ *👾 MysticCoins:* ${money}
┣ *🪙 Tokens:* ${joincount}
┣ *🎟️ Premium:* ${user.premiumTime > 0 ? '✅' : (isPrems ? '✅' : '❌') || ''}
┗━━━━━━━━━━━━━━━━┛
${readMore}
┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔹𝕆𝕋 𝕆𝔽ℂ 𝕆 𝕊𝕌𝔹 𝔹𝕆𝕋 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ${(conn.user.jid == global.conn.user.jid ? '' : `Jadibot de: https://wa.me/${global.conn.user.jid.split`@`[0]}`) || '*Este es el Bot oficial*'}
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕊𝕆𝕃𝕌ℂ𝕀𝕆ℕ 𝔸 𝔼ℝℝ𝕆ℝ𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣➤ Mensajes en espera
┣ ࿅်ၚ⧼➢ ⭐ _${usedPrefix}fixmsgespera_
┣➤ Mensajes en espera (owner)
┣ ࿅်ၚ⧼➢ ⭐ _${usedPrefix}dsowner_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕀ℕ𝔽𝕆 𝔹𝕆𝕋 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}terminosycondiciones_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}grupos_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}estado_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}infobot_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}speedtest_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}donar_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}owner_
┣ ࿅်ၚ⧼➢ 💟 _${usedPrefix}script_
┣ ࿅်ၚ⧼➢ 💟 _Bot_ (𝑢𝑠𝑜 𝑠𝑖𝑛 𝑝𝑟𝑒𝑓𝑖𝑗𝑜)
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕌ℕ𝔼 𝕌ℕ 𝔹𝕆𝕋 𝔸 𝕋𝕌 𝔾ℝ𝕌ℙ𝕆 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}join *<enlace / link / url>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕊𝔼ℝ𝔹𝕆𝕋 - 𝕁𝔸𝔻𝕀𝔹𝕆𝕋 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🤖 _${usedPrefix}serbot_
┣ ࿅်ၚ⧼➢ 🤖 _${usedPrefix}stop_
┣ ࿅်ၚ⧼➢ 🤖 _${usedPrefix}bots_
┗━━━━━━━━━━━━━━━━┛  

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕁𝕌𝔼𝔾𝕆𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}mates *<noob / easy / medium / hard / extreme /impossible /impossible2>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}fake *<texto1> <@tag> <texto2>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}ppt *<papel / tijera /piedra>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}prostituto *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}prostituta *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}gay2 *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}lesbiana *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}pajero *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}pajera *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}puto *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}puta *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}manco *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}manca *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}rata *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}love *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}doxear *<nombre / @tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}pregunta *<texto>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}suitpvp *<@tag>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}slot *<apuesta>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}ttt *<nombre sala>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}delttt_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}acertijo_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}simi *<texto>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}top *<texto>*_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}topgays_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}topotakus_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}formarpareja_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}verdad_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}reto_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}cancion_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}pista_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}akinator_
┣ ࿅်ၚ⧼➢ 🎖️ _${usedPrefix}wordfind_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔸ℂ𝕋𝕀𝕍𝔸ℝ 𝕆 𝔻𝔼𝕊𝔸ℂ𝕋𝕀𝕍𝔸ℝ />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *welcome*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *welcome*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *modohorny*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *modohorny*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antilink*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antilink*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antilink2*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antilink2*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *detect*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *detect*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *audios*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *audios*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *autosticker*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *autosticker*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antiviewonce*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antiviewonce*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antitoxic*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antitoxic*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antitraba*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antitraba*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antiarabes*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antiarabes*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *modoadmin*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *modoadmin*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}enable *antidelete*_
┣ ࿅်ၚ⧼➢ ☑️ _${usedPrefix}disable *antidelete*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┣ *< ℝ𝔼ℙ𝕆ℝ𝕋𝔸ℝ 𝔼ℝℝ𝕆ℝ𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🔰 _${usedPrefix}reporte *<texto>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔻𝔼𝕊ℂ𝔸ℝ𝔾𝔸𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}instagram *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}mediafire *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}gitclone *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}gdrive *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}tiktok *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}tiktokimg *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}xnxxdl *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}xvideosdl *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}twitter *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}fb *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ytshort *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ytmp3 *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ytmp4 *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ytmp3doc *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ytmp4doc *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}videodoc *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}dapk2 *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}stickerpack *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}play *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}play2 *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}play.1 *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}play.2 *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}playdoc *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}playdoc2 *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}playlist *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}spotify *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}ringtone *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}soundcloud *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}imagen *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}pinterest *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}wallpaper *<texto>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}pptiktok *<nombre de usuario>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}igstalk *<nombre de usuario>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}igstory *<nombre de usuario>*_
┣ ࿅်ၚ⧼➢ 📥 _${usedPrefix}tiktokstalk *<username>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔹𝕌𝕊ℂ𝔸𝔻𝕆ℝ𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}githubsearch *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}pelisplus *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}modapk *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}stickersearch *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}stickersearch2 *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}xnxxsearch *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}animeinfo *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}google *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}letra *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}wikipedia *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}ytsearch *<texto>*_
┣ ࿅်ၚ⧼➢ 🔍 _${usedPrefix}playstore *<texto>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔾ℝ𝕌ℙ𝕆𝕊 />* 
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}add *<numero>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}kick *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}kick2 *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}listanum *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}kicknum *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}grupo *<abrir / cerrar>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}grouptime *<opcion> <tiempo>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}promote *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}demote *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _admins *<texto>*_ (𝑢𝑠𝑜 𝑠𝑖𝑛 𝑝𝑟𝑒𝑓𝑖𝑗𝑜)
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}demote *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}infogroup_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}resetlink_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}link_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}setname *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}setdesc *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}invocar *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}setwelcome *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}setbye *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}hidetag *<texto>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}hidetag *<audio>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}hidetag *<video>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}hidetag *<imagen>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}warn *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}unwarn *<@tag>*_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}listwarn_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}fantasmas_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}destraba_
┣ ࿅်ၚ⧼➢ 💎 _${usedPrefix}setpp *<imagen>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℂ𝕆ℕ𝕍𝔼ℝ𝕋𝕀𝔻𝕆ℝ𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}toanime *<imagen>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}togifaud *<video>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}toimg *<sticker>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tomp3 *<video>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tomp3 *<nota de voz>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}toptt *<video / audio>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tovideo *<sticker>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tourl *<video / imagen / audio>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tts *<idioma> <texto>*_
┣ ࿅်ၚ⧼➢ 🧧 _${usedPrefix}tts *<efecto> <texto>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔼𝔽𝔼ℂ𝕋𝕆𝕊 𝕐 𝕃𝕆𝔾𝕆𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}logos *<efecto> <texto>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}logochristmas *<texto>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}logocorazon *<texto>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}ytcomment *<texto>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}hornycard *<@tag>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}simpcard *<@tag>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}lolice *<@tag>*_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}itssostupid_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}pixelar_
┣ ࿅်ၚ⧼➢ 🖍️ _${usedPrefix}blur_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔽ℝ𝔸𝕊𝔼𝕊 𝕐 𝕋𝔼𝕏𝕋𝕆𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🥀 _${usedPrefix}piropo_
┣ ࿅်ၚ⧼➢ 🥀 _${usedPrefix}consejo_
┣ ࿅်ၚ⧼➢ 🥀 _${usedPrefix}fraseromantica_
┣ ࿅်ၚ⧼➢ 🥀 _${usedPrefix}historiaromantica_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℝ𝔸ℕ𝔻-𝔸ℕ𝕀𝕄𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🧿 _${usedPrefix}menuanimes_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℝ𝔸ℕ𝔻𝕆𝕄 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}kpop *<blackpink / exo / bts>*_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}cristianoronaldo_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}messi_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}cat_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}dog_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}meme_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}itzy_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}blackpink_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}navidad_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpmontaña_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}pubg_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpgaming_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpaesthetic_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpaesthetic2_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wprandom_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wallhp_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpvehiculo_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}wpmoto_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}coffee_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}pentol_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}caricatura_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}ciberespacio_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}technology_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}doraemon_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}hacker_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}planeta_
┣ ࿅်ၚ⧼➢ 👾 _${usedPrefix}randomprofile_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℂ𝕆𝕄𝔸ℕ𝔻𝕆𝕊 +𝟙𝟠 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🔞 _${usedPrefix}labiblia_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔼𝔽𝔼ℂ𝕋𝕆𝕊 𝔻𝔼 𝔸𝕌𝔻𝕀𝕆𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┃*- 𝚁𝙴𝚂𝙿𝙾𝙽𝙳𝙴 𝙰 𝙰𝚄𝙳𝙸𝙾 𝙾 𝙽𝙾𝚃𝙰 𝙳𝙴 𝚅𝙾𝚉*
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}bass_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}blown_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}deep_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}earrape_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}fast_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}fat_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}nightcore_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}reverse_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}robot_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}slow_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}smooth_
┣ ࿅်ၚ⧼➢ 🎤 _${usedPrefix}tupai_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℂℍ𝔸𝕋 𝔸ℕ𝕆ℕ𝕀𝕄𝕆 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 📳 _${usedPrefix}start_
┣ ࿅်ၚ⧼➢ 📳 _${usedPrefix}next_
┣ ࿅်ၚ⧼➢ 📳 _${usedPrefix}leave_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝔸𝕌𝔻𝕀𝕆𝕊 />*   
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🔊 _${usedPrefix}menuaudios_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℍ𝔼ℝℝ𝔸𝕄𝕀𝔼ℕ𝕋𝔸𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}chatgpt *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}delchatgpt
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}gptvoz *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}dall-e *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}spamwa *<numero|texto|cantidad>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}tamaño *<cantidad> <imagen / video>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}readviewonce *<imagen / video>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}clima *<país> <ciudad>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}encuesta *<texto1|texto2...>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}afk *<motivo>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}ocr *<responde a imagen>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}hd *<responde a imagen>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}acortar *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}calc *<operacion math>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}del *<mensaje>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}whatmusic *<audio>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}readqr *<imagen (QR)>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}qrcode *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}readmore *<texto1| texto2>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}styletext *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}traducir *<texto>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}nowa *<numero>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}covid *<pais>*_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}horario_
┣ ࿅်ၚ⧼➢ 🛠️ _${usedPrefix}dropmail_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< ℝℙ𝔾 - 𝕃𝕀𝕄𝕀𝕋𝔼𝕊 - 𝔼ℂ𝕆ℕ𝕆𝕄𝕀𝔸 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}adventure_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}cazar_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}cofre_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}balance_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}claim_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}heal_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}lb_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}levelup_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}myns_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}perfil_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}work_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}minar_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}minar2_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}buy_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}buyall_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}verificar_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}robar *<cantidad> <@tag>*_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}transfer *<tipo> <cantidad> <@tag>*_
┣ ࿅်ၚ⧼➢ 💵 _${usedPrefix}unreg *<numero de serie>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕊𝕋𝕀ℂ𝕂𝔼ℝ𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}sticker *<responder a imagen o video>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}sticker *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}sticker2 *<responder a imagen o video>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}sticker2 *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}s *<responder a imagen o video>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}s *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}s2 *<responder a imagen o video>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}s2 *<enlace / link / url>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}emojimix *<emoji 1>&<emoji 2>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}scircle *<imagen>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}sremovebg *<imagen>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}semoji *<tipo> <emoji>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}qc *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}attp *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}attp2 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}attp3 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}ttp *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}ttp2 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}ttp3 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}ttp4 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}ttp5 *<texto>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}pat *<@tag>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}slap *<@tag>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}kiss *<@tag>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}dado_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}wm *<packname> <author>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}stickermarker *<efecto> <imagen>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}stickerfilter *<efecto> <imagen>*_
┣ ࿅်ၚ⧼➢ 👽 _${usedPrefix}cartoon *<responder a imagen>*_
┗━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━┓
┃ *< 𝕆𝕎ℕ𝔼ℝ 𝕐 𝕄𝕆𝔻𝔼ℝ𝔸𝔻𝕆ℝ𝔼𝕊 />*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣ ࿅်ၚ⧼➢ 👑 > *<funcion>*
┣ ࿅်ၚ⧼➢ 👑 => *<funcion>*
┣ ࿅်ၚ⧼➢ 👑 $ *<funcion>*
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}setprefix *<prefijo>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}desactivarwa *<numero>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}resetprefix_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}autoadmin_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}chetar_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}leavegc_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}cajafuerte_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}blocklist_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}block *<@tag / numero>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}unblock *<@tag / numero>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *restrict*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *restrict*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *autoread*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *autoread*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *public*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *public*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *pconly*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *pconly*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *gconly*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *gconly*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *anticall*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *anticall*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *antiprivado*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *antiprivado*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *modejadibot*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *modejadibot*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *audios_bot*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *audios_bot*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}enable *antispam*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}disable *antispam*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}msg *<texto>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}banchat_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}unbanchat_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}resetuser *<@tag>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}banuser *<@tag>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}unbanuser *<@tag>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}dardiamantes *<@tag> <cantidad>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}añadirxp *<@tag> <cantidad>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}banuser *<@tag>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bc *<texto>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcchats *<texto>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcgc *<texto>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcgc2 *<audio>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcgc2 *<video>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcgc2 *<imagen>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}bcbot *<texto>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}cleartpm_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}restart_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}update_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}banlist_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}addprem *<@tag> <tiempo>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}addprem2 *<@tag> <tiempo>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}addprem3 *<@tag> <tiempo>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}addprem4 *<@tag> <tiempo>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}delprem *<@tag>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}listcmd_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}setppbot *<responder a imagen>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}addcmd *<texto> <responder a sticker/imagen>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}delcmd *<responder a sticker/imagen con comando o texto asignado>*_
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}saveimage
┣ ࿅်ၚ⧼➢ 👑 _${usedPrefix}viewimage
┗━━━━━━━━━━━━━━━━┛`.trim();
    if (m.isGroup) {
      // await conn.sendFile(m.chat, vn, 'menu.mp3', null, m, true, { type: 'audioMessage', ptt: true})
      const fkontak2 = {'key': {'participants': '0@s.whatsapp.net', 'remoteJid': 'status@broadcast', 'fromMe': false, 'id': 'Halo'}, 'message': {'contactMessage': {'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}, 'participant': '0@s.whatsapp.net'};
      conn.sendMessage(m.chat, {image: pp, caption: str.trim(), mentions: [...str.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net')}, {quoted: m});
    } else {
      // await conn.sendFile(m.chat, vn, 'menu.mp3', null, m, true, { type: 'audioMessage', ptt: true})
      const fkontak2 = {'key': {'participants': '0@s.whatsapp.net', 'remoteJid': 'status@broadcast', 'fromMe': false, 'id': 'Halo'}, 'message': {'contactMessage': {'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}, 'participant': '0@s.whatsapp.net'};
      conn.sendMessage(m.chat, {image: pp, caption: str.trim(), mentions: [...str.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net')}, {quoted: fkontak2});
    }
  } catch {
    conn.reply(m.chat, '*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝙻 𝙼𝙴𝙽𝚄 𝚃𝙸𝙴𝙽𝙴 𝚄𝙽 𝙴𝚁𝚁𝙾𝚁 𝚈 𝙽𝙾 𝙵𝚄𝙴 𝙿𝙾𝚂𝙸𝙱𝙻𝙴 𝙴𝙽𝚅𝙸𝙰𝚁𝙻𝙾, 𝚁𝙴𝙿𝙾𝚁𝚃𝙴𝙻𝙾 𝙰𝙻 𝙿𝚁𝙾𝙿𝙸𝙴𝚃𝙰𝚁𝙸𝙾 𝙳𝙴𝙻 𝙱𝙾𝚃*', m);
  }
};
handler.command = /^(menu|menú|memu|memú|help|info|comandos|allmenu|2help|menu1.2|ayuda|commands|commandos|cmd)$/i;
handler.exp = 50;
handler.fail = null;
export default handler;
function clockString(ms) {
  const h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
  const m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  const s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(':');
}
